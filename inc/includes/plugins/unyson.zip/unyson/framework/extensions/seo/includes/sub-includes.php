<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

require_once dirname( __FILE__ ) . '/option-types/seo-tags/class-fw-option-type-seo-tags.php';
